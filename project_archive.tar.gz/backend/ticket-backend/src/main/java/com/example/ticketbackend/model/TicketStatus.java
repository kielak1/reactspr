package com.example.ticketbackend.model;

public enum TicketStatus {
    OPEN, IN_PROGRESS, CLOSED;
}
